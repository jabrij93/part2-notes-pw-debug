import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f925d25"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=4f925d25"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleSubmit,
  handleUsernameChange,
  handlePasswordChange,
  username,
  password
}) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-testid": "username",
            value: username,
            onChange: handleUsernameChange
          },
          void 0,
          false,
          {
            fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
            lineNumber: 17,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
        lineNumber: 15,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-testid": "password",
            type: "password",
            value: password,
            onChange: handlePasswordChange
          },
          void 0,
          false,
          {
            fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
            lineNumber: 25,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
        lineNumber: 32,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
      lineNumber: 14,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx",
    lineNumber: 11,
    columnNumber: 5
  }, this);
};
_c = LoginForm;
LoginForm.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  handleUsernameChange: PropTypes.func.isRequired,
  handlePasswordChange: PropTypes.func.isRequired,
  username: PropTypes.string.isRequired,
  password: PropTypes.string.isRequired
};
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007QUFYTixPQUFPQSxvQkFBZTtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVsQyxNQUFNQyxZQUFZQSxDQUFDO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFFVCx1QkFBQyxVQUFLLFVBQVVKLGNBQ2Q7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFZO0FBQUEsWUFDWixPQUFPRztBQUFBQSxZQUNQLFVBQVVGO0FBQUFBO0FBQUFBLFVBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2lDO0FBQUEsV0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFZO0FBQUEsWUFDWixNQUFLO0FBQUEsWUFDTCxPQUFPRztBQUFBQSxZQUNQLFVBQVVGO0FBQUFBO0FBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlDO0FBQUEsV0FObkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBbEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUVKO0FBQUNHLEtBakNLTjtBQW1DTkEsVUFBVU8sWUFBWTtBQUFBLEVBQ3BCTixjQUFjRixVQUFVUyxLQUFLQztBQUFBQSxFQUM3QlAsc0JBQXNCSCxVQUFVUyxLQUFLQztBQUFBQSxFQUNyQ04sc0JBQXNCSixVQUFVUyxLQUFLQztBQUFBQSxFQUNyQ0wsVUFBVUwsVUFBVVcsT0FBT0Q7QUFBQUEsRUFDM0JKLFVBQVVOLFVBQVVXLE9BQU9EO0FBQzdCO0FBRUEsZUFBZVQ7QUFBUyxJQUFBTTtBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwiTG9naW5Gb3JtIiwiaGFuZGxlU3VibWl0IiwiaGFuZGxlVXNlcm5hbWVDaGFuZ2UiLCJoYW5kbGVQYXNzd29yZENoYW5nZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJfYyIsInByb3BUeXBlcyIsImZ1bmMiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IExvZ2luRm9ybSA9ICh7XG4gIGhhbmRsZVN1Ym1pdCxcbiAgaGFuZGxlVXNlcm5hbWVDaGFuZ2UsXG4gIGhhbmRsZVBhc3N3b3JkQ2hhbmdlLFxuICB1c2VybmFtZSxcbiAgcGFzc3dvcmRcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkxvZ2luPC9oMj5cblxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgdXNlcm5hbWVcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVc2VybmFtZUNoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICBwYXNzd29yZFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXNzd29yZENoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5Mb2dpbkZvcm0ucHJvcFR5cGVzID0ge1xuICBoYW5kbGVTdWJtaXQ6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIGhhbmRsZVVzZXJuYW1lQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBoYW5kbGVQYXNzd29yZENoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgdXNlcm5hbWU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgcGFzc3dvcmQ6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm0iXSwiZmlsZSI6Ii9Vc2Vycy9hZG1pbi9NaW5pIFByb2plY3RzL3BhcnQyLW5vdGVzLWZlLWRlYnVnL3NyYy9jb21wb25lbnRzL0xvZ2luRm9ybS5qc3gifQ==