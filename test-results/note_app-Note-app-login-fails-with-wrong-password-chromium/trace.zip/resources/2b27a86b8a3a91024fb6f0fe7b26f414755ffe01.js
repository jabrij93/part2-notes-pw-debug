import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f925d25"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Footer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Footer = () => {
  const footerStyle = {
    color: "green",
    fontStyle: "italic",
    fontSize: 16
  };
  return /* @__PURE__ */ jsxDEV("div", { style: footerStyle, children: [
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Footer.jsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("em", { children: "Note app, Department of Computer Science, University of Helsinki 2024" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Footer.jsx",
      lineNumber: 11,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Footer.jsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
};
_c = Footer;
export default Footer;
var _c;
$RefreshReg$(_c, "Footer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Footer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTixPQUFNQSxvQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuQixRQUFNQyxjQUFjO0FBQUEsSUFDbEJDLE9BQU87QUFBQSxJQUNQQyxXQUFXO0FBQUEsSUFDWEMsVUFBVTtBQUFBLEVBQ1o7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBT0gsYUFDVjtBQUFBLDJCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxRQUFHLHFGQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUU7QUFBQSxPQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDSSxLQWJLTDtBQWVOLGVBQWVBO0FBQU0sSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZvb3RlciIsImZvb3RlclN0eWxlIiwiY29sb3IiLCJmb250U3R5bGUiLCJmb250U2l6ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRm9vdGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBGb290ZXIgPSAoKSA9PiB7XG4gIGNvbnN0IGZvb3RlclN0eWxlID0ge1xuICAgIGNvbG9yOiAnZ3JlZW4nLFxuICAgIGZvbnRTdHlsZTogJ2l0YWxpYycsXG4gICAgZm9udFNpemU6IDE2XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e2Zvb3RlclN0eWxlfT5cbiAgICAgIDxiciAvPlxuICAgICAgPGVtPk5vdGUgYXBwLCBEZXBhcnRtZW50IG9mIENvbXB1dGVyIFNjaWVuY2UsIFVuaXZlcnNpdHkgb2YgSGVsc2lua2kgMjAyNDwvZW0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyIl0sImZpbGUiOiIvVXNlcnMvYWRtaW4vTWluaSBQcm9qZWN0cy9wYXJ0Mi1ub3Rlcy1mZS1kZWJ1Zy9zcmMvY29tcG9uZW50cy9Gb290ZXIuanN4In0=