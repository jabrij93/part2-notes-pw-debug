import {
  require_react
} from "/node_modules/.vite/deps/chunk-NVDSUZN5.js?v=4f925d25";
import "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4f925d25";
export default require_react();
//# sourceMappingURL=react.js.map
