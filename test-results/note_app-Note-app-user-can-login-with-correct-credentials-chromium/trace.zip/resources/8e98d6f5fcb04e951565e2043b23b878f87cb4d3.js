import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NoteForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f925d25"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4f925d25"; const useState = __vite__cjsImport3_react["useState"];
import DatePicker from "/node_modules/.vite/deps/react-datepicker.js?v=4f925d25";
import "/node_modules/react-datepicker/dist/react-datepicker.css";
const NoteForm = ({ createNote }) => {
  _s();
  const [newNote, setNewNote] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const localISOTime = selectedDate ? new Date(selectedDate.getTime() - selectedDate.getTimezoneOffset() * 6e4).toISOString() : null;
  const addNote = (event) => {
    event.preventDefault();
    if (!selectedDate)
      return;
    createNote({
      content: newNote,
      date: localISOTime,
      // Keeps local time without shifting
      important: true
    });
    setNewNote("");
    setSelectedDate(null);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create a new note" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addNote, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          value: newNote,
          onChange: (event) => setNewNote(event.target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
          lineNumber: 33,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "Pick a date:" }, void 0, false, {
          fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
          lineNumber: 38,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          DatePicker,
          {
            selected: selectedDate,
            onChange: (date) => setSelectedDate(date),
            dateFormat: "yyyy-dd-MM",
            placeholderText: "Click to select a date"
          },
          void 0,
          false,
          {
            fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
            lineNumber: 39,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "save" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
};
_s(NoteForm, "CVvdGP8Oj4tBqI1dMmLRMA0VUqQ=");
_c = NoteForm;
export default NoteForm;
var _c;
$RefreshReg$(_c, "NoteForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/NoteForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzJCQTdCTjtBQUFpQixNQUFRLGNBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEMsT0FBT0EsZ0JBQWdCO0FBQ3ZCLE9BQU87QUFFUCxNQUFNQyxXQUFXQSxDQUFDLEVBQUVDLFdBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlGLFNBQVMsSUFBSTtBQUVyRCxRQUFNRyxlQUFlRixlQUNqQixJQUFJRyxLQUFLSCxhQUFhSSxRQUFRLElBQUlKLGFBQWFLLGtCQUFrQixJQUFJLEdBQUssRUFBRUMsWUFBWSxJQUN4RjtBQUVKLFFBQU1DLFVBQVVBLENBQUNDLFVBQVU7QUFDekJBLFVBQU1DLGVBQWU7QUFFckIsUUFBSSxDQUFDVDtBQUFjO0FBRW5CTCxlQUFXO0FBQUEsTUFDVGUsU0FBU2I7QUFBQUEsTUFDVGMsTUFBTVQ7QUFBQUE7QUFBQUEsTUFDTlUsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUVEZCxlQUFXLEVBQUU7QUFDYkcsb0JBQWdCLElBQUk7QUFBQSxFQUN0QjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBRXJCLHVCQUFDLFVBQUssVUFBVU0sU0FDZDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPVjtBQUFBQSxVQUNQLFVBQVUsQ0FBQVcsVUFBU1YsV0FBV1UsTUFBTUssT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW9EO0FBQUEsTUFFcEQsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sNEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQ25CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxVQUFVZDtBQUFBQSxZQUNWLFVBQVUsQ0FBQVcsU0FBUVYsZ0JBQWdCVSxJQUFJO0FBQUEsWUFDdEMsWUFBVztBQUFBLFlBQ1gsaUJBQWdCO0FBQUE7QUFBQSxVQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJMkM7QUFBQSxXQU43QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsU0FkNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNmLEdBN0NLRixVQUFRO0FBQUFxQixLQUFSckI7QUErQ04sZUFBZUE7QUFBUSxJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkRhdGVQaWNrZXIiLCJOb3RlRm9ybSIsImNyZWF0ZU5vdGUiLCJfcyIsIm5ld05vdGUiLCJzZXROZXdOb3RlIiwidXNlU3RhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJsb2NhbElTT1RpbWUiLCJEYXRlIiwiZ2V0VGltZSIsImdldFRpbWV6b25lT2Zmc2V0IiwidG9JU09TdHJpbmciLCJhZGROb3RlIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImNvbnRlbnQiLCJkYXRlIiwiaW1wb3J0YW50IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGVGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IERhdGVQaWNrZXIgZnJvbSAncmVhY3QtZGF0ZXBpY2tlcidcbmltcG9ydCBcInJlYWN0LWRhdGVwaWNrZXIvZGlzdC9yZWFjdC1kYXRlcGlja2VyLmNzc1wiXG5cbmNvbnN0IE5vdGVGb3JtID0gKHsgY3JlYXRlTm90ZSB9KSA9PiB7XG4gIGNvbnN0IFtuZXdOb3RlLCBzZXROZXdOb3RlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUobnVsbCkgLy8gRGVmYXVsdCBkYXRlIGlzIHRvZGF5XG5cbiAgY29uc3QgbG9jYWxJU09UaW1lID0gc2VsZWN0ZWREYXRlIFxuICAgID8gbmV3IERhdGUoc2VsZWN0ZWREYXRlLmdldFRpbWUoKSAtIHNlbGVjdGVkRGF0ZS5nZXRUaW1lem9uZU9mZnNldCgpICogNjAwMDApLnRvSVNPU3RyaW5nKCkgXG4gICAgOiBudWxsO1xuXG4gIGNvbnN0IGFkZE5vdGUgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBpZiAoIXNlbGVjdGVkRGF0ZSkgcmV0dXJuIC8vIFByZXZlbnQgc3VibWl0dGluZyBpZiBubyBkYXRlIGlzIHNlbGVjdGVkXG5cbiAgICBjcmVhdGVOb3RlKHtcbiAgICAgIGNvbnRlbnQ6IG5ld05vdGUsXG4gICAgICBkYXRlOiBsb2NhbElTT1RpbWUsIC8vIEtlZXBzIGxvY2FsIHRpbWUgd2l0aG91dCBzaGlmdGluZ1xuICAgICAgaW1wb3J0YW50OiB0cnVlXG4gICAgfSlcblxuICAgIHNldE5ld05vdGUoJycpXG4gICAgc2V0U2VsZWN0ZWREYXRlKG51bGwpIC8vIFJlc2V0IHRvIGN1cnJlbnQgZGF0ZVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkNyZWF0ZSBhIG5ldyBub3RlPC9oMj5cblxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2FkZE5vdGV9PlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB2YWx1ZT17bmV3Tm90ZX1cbiAgICAgICAgICBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TmV3Tm90ZShldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbD5QaWNrIGEgZGF0ZTo8L2xhYmVsPlxuICAgICAgICAgIDxEYXRlUGlja2VyXG4gICAgICAgICAgICBzZWxlY3RlZD17c2VsZWN0ZWREYXRlfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2RhdGUgPT4gc2V0U2VsZWN0ZWREYXRlKGRhdGUpfVxuICAgICAgICAgICAgZGF0ZUZvcm1hdD1cInl5eXktZGQtTU1cIiAvLyBEYXRlIGZvcm1hdFxuICAgICAgICAgICAgcGxhY2Vob2xkZXJUZXh0PVwiQ2xpY2sgdG8gc2VsZWN0IGEgZGF0ZVwiIC8vIFBsYWNlaG9sZGVyIHdoZW4gZW1wdHlcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+c2F2ZTwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGVGb3JtIl0sImZpbGUiOiIvVXNlcnMvYWRtaW4vTWluaSBQcm9qZWN0cy9wYXJ0Mi1ub3Rlcy1mZS1kZWJ1Zy9zcmMvY29tcG9uZW50cy9Ob3RlRm9ybS5qc3gifQ==