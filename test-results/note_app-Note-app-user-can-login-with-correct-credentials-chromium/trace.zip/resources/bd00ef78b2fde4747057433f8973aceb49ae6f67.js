import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f925d25"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4f925d25"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Note from "/src/components/Note.jsx?t=1742501135514";
import Notification from "/src/components/Notification.jsx";
import Footer from "/src/components/Footer.jsx";
import noteService from "/src/services/notes.js";
import loginService from "/src/services/login.js";
import LoginForm from "/src/components/LoginForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import NoteForm from "/src/components/NoteForm.jsx";
const App = () => {
  _s();
  const [notes, setNotes] = useState([]);
  const [showAll, setShowAll] = useState(true);
  const [errorMessage, setErrorMessage] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [loginVisible, setLoginVisible] = useState(false);
  const noteFormRef = useRef();
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedNoteappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      noteService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    noteService.getAll().then((initialNotes) => {
      setNotes(initialNotes);
    });
  }, []);
  const toggleImportanceOf = (id) => {
    const note = notes.find((n) => n.id === id);
    const changedNote = { ...note, important: !note.important };
    noteService.update(id, changedNote).then((returnedNote) => {
      setNotes(notes.map((note2) => note2.id !== id ? note2 : returnedNote));
    }).catch((error) => {
      setErrorMessage(
        `Note '${note.content}' was already removed from server`
      );
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    });
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem(
        "loggedNoteappUser",
        JSON.stringify(user2)
      );
      noteService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("wrong credentials");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedNoteappUser");
    setUser(null);
  };
  const addNote = (noteObject) => {
    noteFormRef.current.toggleVisibility();
    noteService.create(noteObject).then((returnedNote) => {
      setNotes(notes.concat(returnedNote));
    });
  };
  const notesToShow = showAll ? notes : notes.filter((note) => note.important);
  const loginForm = () => {
    const hideWhenVisible = { display: loginVisible ? "none" : "" };
    const showWhenVisible = { display: loginVisible ? "" : "none" };
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setLoginVisible(true), children: "log in" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 105,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
        /* @__PURE__ */ jsxDEV(
          LoginForm,
          {
            username,
            password,
            handleUsernameChange: ({ target }) => setUsername(target.value),
            handlePasswordChange: ({ target }) => setPassword(target.value),
            handleSubmit: handleLogin
          },
          void 0,
          false,
          {
            fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
            lineNumber: 108,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setLoginVisible(false), children: "cancel" }, void 0, false, {
          fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Notes" }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    !user && loginForm(),
    user && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged in"
      ] }, void 0, true, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 129,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new note", ref: noteFormRef, children: /* @__PURE__ */ jsxDEV(
        NoteForm,
        {
          createNote: addNote
        },
        void 0,
        false,
        {
          fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
          lineNumber: 131,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
        lineNumber: 130,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 127,
      columnNumber: 16
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowAll(!showAll), children: [
      "show ",
      showAll ? "important" : "all"
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 138,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 137,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: notesToShow.map(
      (note) => /* @__PURE__ */ jsxDEV(
        Note,
        {
          note,
          toggleImportance: () => toggleImportanceOf(note.id)
        },
        note.id,
        false,
        {
          fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
          lineNumber: 144,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
      lineNumber: 151,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx",
    lineNumber: 122,
    columnNumber: 5
  }, this);
};
_s(App, "LpHXdO26v8l2GvxZLlkcuuKZ5rE=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-fe-debug/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0dVOzJCQXhHVjtBQUFtQkEsb0JBQWlCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBRXJCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUMsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJRixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDRyxjQUFjQyxlQUFlLElBQUlKLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNLLFVBQVVDLFdBQVcsSUFBSU4sU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ08sVUFBVUMsV0FBVyxJQUFJUixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDUyxNQUFNQyxPQUFPLElBQUlWLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNXLGNBQWNDLGVBQWUsSUFBSVosU0FBUyxLQUFLO0FBRXRELFFBQU1hLGNBQWNDLE9BQU87QUFFM0IzQixZQUFVLE1BQU07QUFDZCxVQUFNNEIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTU4sUUFBT1UsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q0wsY0FBUUQsS0FBSTtBQUNabEIsa0JBQVk4QixTQUFTWixNQUFLYSxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMbkMsWUFBVSxNQUFNO0FBQ2RJLGdCQUNHZ0MsT0FBTyxFQUNQQyxLQUFLLENBQUFDLGlCQUFnQjtBQUNwQjFCLGVBQVMwQixZQUFZO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBRUwsUUFBTUMscUJBQXFCQSxDQUFBQyxPQUFNO0FBQy9CLFVBQU1DLE9BQU85QixNQUFNK0IsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSCxPQUFPQSxFQUFFO0FBQ3hDLFVBQU1JLGNBQWMsRUFBRSxHQUFHSCxNQUFNSSxXQUFXLENBQUNKLEtBQUtJLFVBQVU7QUFFMUR6QyxnQkFDRzBDLE9BQU9OLElBQUlJLFdBQVcsRUFDdEJQLEtBQUssQ0FBQVUsaUJBQWdCO0FBQ3BCbkMsZUFBU0QsTUFBTXFDLElBQUksQ0FBQVAsVUFBUUEsTUFBS0QsT0FBT0EsS0FBS0MsUUFBT00sWUFBWSxDQUFDO0FBQUEsSUFDbEUsQ0FBQyxFQUNBRSxNQUFNLENBQUFDLFVBQVM7QUFDZGpDO0FBQUFBLFFBQ0csU0FBUXdCLEtBQUtVLE9BQVE7QUFBQSxNQUN4QjtBQUNBQyxpQkFBVyxNQUFNO0FBQ2ZuQyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsR0FBSTtBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNb0MsY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBRXJCLFFBQUk7QUFDRixZQUFNakMsUUFBTyxNQUFNakIsYUFBYW1ELE1BQU07QUFBQSxRQUNwQ3RDO0FBQUFBLFFBQVVFO0FBQUFBLE1BQ1osQ0FBQztBQUNEUyxhQUFPQyxhQUFhMkI7QUFBQUEsUUFDbEI7QUFBQSxRQUFxQnpCLEtBQUswQixVQUFVcEMsS0FBSTtBQUFBLE1BQzFDO0FBQ0FsQixrQkFBWThCLFNBQVNaLE1BQUthLEtBQUs7QUFDL0JaLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBU3NDLFdBQVc7QUFDbEIxQyxzQkFBZ0IsbUJBQW1CO0FBQ25DbUMsaUJBQVcsTUFBTTtBQUNmbkMsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFFBQU0yQyxlQUFlQSxNQUFNO0FBQ3pCL0IsV0FBT0MsYUFBYStCLFdBQVcsbUJBQW1CO0FBQ2xEdEMsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUVBLFFBQU11QyxVQUFVQSxDQUFDQyxlQUFlO0FBQzlCckMsZ0JBQVlzQyxRQUFRQyxpQkFBaUI7QUFDckM3RCxnQkFDRzhELE9BQU9ILFVBQVUsRUFDakIxQixLQUFLLENBQUFVLGlCQUFnQjtBQUNwQm5DLGVBQVNELE1BQU13RCxPQUFPcEIsWUFBWSxDQUFDO0FBQUEsSUFDckMsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNcUIsY0FBY3RELFVBQ2hCSCxRQUNBQSxNQUFNMEQsT0FBTyxDQUFBNUIsU0FBUUEsS0FBS0ksU0FBUztBQUV2QyxRQUFNeUIsWUFBWUEsTUFBTTtBQUN0QixVQUFNQyxrQkFBa0IsRUFBRUMsU0FBU2hELGVBQWUsU0FBUyxHQUFHO0FBQzlELFVBQU1pRCxrQkFBa0IsRUFBRUQsU0FBU2hELGVBQWUsS0FBSyxPQUFPO0FBRTlELFdBQ0UsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUksT0FBTytDLGlCQUNWLGlDQUFDLFlBQU8sU0FBUyxNQUFNOUMsZ0JBQWdCLElBQUksR0FBRyxzQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBT2dELGlCQUNWO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQTtBQUFBLFlBQ0Esc0JBQXNCLENBQUMsRUFBRUMsT0FBTyxNQUFNdkQsWUFBWXVELE9BQU9DLEtBQUs7QUFBQSxZQUM5RCxzQkFBc0IsQ0FBQyxFQUFFRCxPQUFPLE1BQU1yRCxZQUFZcUQsT0FBT0MsS0FBSztBQUFBLFlBQzlELGNBQWN0QjtBQUFBQTtBQUFBQSxVQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLNEI7QUFBQSxRQUU1Qix1QkFBQyxZQUFPLFNBQVMsTUFBTTVCLGdCQUFnQixLQUFLLEdBQUcsc0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxXQVJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsZ0JBQWEsU0FBU1QsZ0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUVuQyxDQUFDTSxRQUFRZ0QsVUFBVTtBQUFBLElBQ25CaEQsUUFBUSx1QkFBQyxTQUNSO0FBQUEsNkJBQUMsT0FBR0E7QUFBQUEsYUFBS3NEO0FBQUFBLFFBQUs7QUFBQSxXQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxZQUFPLFNBQVNoQixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsTUFDckMsdUJBQUMsYUFBVSxhQUFZLFlBQVcsS0FBS2xDLGFBQ3JDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxZQUFZb0M7QUFBQUE7QUFBQUEsUUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDc0IsS0FGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FQTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUVQ7QUFBQSxJQUVBLHVCQUFDLFNBQ0MsaUNBQUMsWUFBTyxTQUFTLE1BQU0vQyxXQUFXLENBQUNELE9BQU8sR0FBRTtBQUFBO0FBQUEsTUFDcENBLFVBQVUsY0FBYztBQUFBLFNBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsUUFDRXNELHNCQUFZcEI7QUFBQUEsTUFBSSxDQUFBUCxTQUNmO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQztBQUFBLFVBQ0Esa0JBQWtCLE1BQU1GLG1CQUFtQkUsS0FBS0QsRUFBRTtBQUFBO0FBQUEsUUFGN0NDLEtBQUtEO0FBQUFBLFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdzRDtBQUFBLElBRXhELEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLE9BN0JUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSjtBQUFDOUIsR0EvSUtELEtBQUc7QUFBQW9FLEtBQUhwRTtBQWlKTixlQUFlQTtBQUFHLElBQUFvRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiTm90ZSIsIk5vdGlmaWNhdGlvbiIsIkZvb3RlciIsIm5vdGVTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTG9naW5Gb3JtIiwiVG9nZ2xhYmxlIiwiTm90ZUZvcm0iLCJBcHAiLCJfcyIsIm5vdGVzIiwic2V0Tm90ZXMiLCJ1c2VTdGF0ZSIsInNob3dBbGwiLCJzZXRTaG93QWxsIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJ1c2VyIiwic2V0VXNlciIsImxvZ2luVmlzaWJsZSIsInNldExvZ2luVmlzaWJsZSIsIm5vdGVGb3JtUmVmIiwidXNlUmVmIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImdldEFsbCIsInRoZW4iLCJpbml0aWFsTm90ZXMiLCJ0b2dnbGVJbXBvcnRhbmNlT2YiLCJpZCIsIm5vdGUiLCJmaW5kIiwibiIsImNoYW5nZWROb3RlIiwiaW1wb3J0YW50IiwidXBkYXRlIiwicmV0dXJuZWROb3RlIiwibWFwIiwiY2F0Y2giLCJlcnJvciIsImNvbnRlbnQiLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZXhjZXB0aW9uIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImFkZE5vdGUiLCJub3RlT2JqZWN0IiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJjcmVhdGUiLCJjb25jYXQiLCJub3Rlc1RvU2hvdyIsImZpbHRlciIsImxvZ2luRm9ybSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgTm90ZSBmcm9tICcuL2NvbXBvbmVudHMvTm90ZSdcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBGb290ZXIgZnJvbSAnLi9jb21wb25lbnRzL0Zvb3RlcidcbmltcG9ydCBub3RlU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL25vdGVzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5Gb3JtJ1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlJ1xuaW1wb3J0IE5vdGVGb3JtIGZyb20gJy4vY29tcG9uZW50cy9Ob3RlRm9ybSdcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbc2hvd0FsbCwgc2V0U2hvd0FsbF0gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvZ2luVmlzaWJsZSwgc2V0TG9naW5WaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IG5vdGVGb3JtUmVmID0gdXNlUmVmKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWROb3RlYXBwVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIG5vdGVTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG5vdGVTZXJ2aWNlXG4gICAgICAuZ2V0QWxsKClcbiAgICAgIC50aGVuKGluaXRpYWxOb3RlcyA9PiB7XG4gICAgICAgIHNldE5vdGVzKGluaXRpYWxOb3RlcylcbiAgICAgIH0pXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRvZ2dsZUltcG9ydGFuY2VPZiA9IGlkID0+IHtcbiAgICBjb25zdCBub3RlID0gbm90ZXMuZmluZChuID0+IG4uaWQgPT09IGlkKVxuICAgIGNvbnN0IGNoYW5nZWROb3RlID0geyAuLi5ub3RlLCBpbXBvcnRhbnQ6ICFub3RlLmltcG9ydGFudCB9XG5cbiAgICBub3RlU2VydmljZVxuICAgICAgLnVwZGF0ZShpZCwgY2hhbmdlZE5vdGUpXG4gICAgICAudGhlbihyZXR1cm5lZE5vdGUgPT4ge1xuICAgICAgICBzZXROb3Rlcyhub3Rlcy5tYXAobm90ZSA9PiBub3RlLmlkICE9PSBpZCA/IG5vdGUgOiByZXR1cm5lZE5vdGUpKVxuICAgICAgfSlcbiAgICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShcbiAgICAgICAgICBgTm90ZSAnJHtub3RlLmNvbnRlbnR9JyB3YXMgYWxyZWFkeSByZW1vdmVkIGZyb20gc2VydmVyYFxuICAgICAgICApXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgICAgICB9LCA1MDAwKVxuICAgICAgfSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oe1xuICAgICAgICB1c2VybmFtZSwgcGFzc3dvcmQsXG4gICAgICB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAnbG9nZ2VkTm90ZWFwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKVxuICAgICAgKVxuICAgICAgbm90ZVNlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ3dyb25nIGNyZWRlbnRpYWxzJylcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcbiAgICAgIH0sIDUwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkTm90ZWFwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgfVxuXG4gIGNvbnN0IGFkZE5vdGUgPSAobm90ZU9iamVjdCkgPT4ge1xuICAgIG5vdGVGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgbm90ZVNlcnZpY2VcbiAgICAgIC5jcmVhdGUobm90ZU9iamVjdClcbiAgICAgIC50aGVuKHJldHVybmVkTm90ZSA9PiB7XG4gICAgICAgIHNldE5vdGVzKG5vdGVzLmNvbmNhdChyZXR1cm5lZE5vdGUpKVxuICAgICAgfSlcbiAgfVxuXG4gIGNvbnN0IG5vdGVzVG9TaG93ID0gc2hvd0FsbFxuICAgID8gbm90ZXNcbiAgICA6IG5vdGVzLmZpbHRlcihub3RlID0+IG5vdGUuaW1wb3J0YW50KVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IHtcbiAgICBjb25zdCBoaWRlV2hlblZpc2libGUgPSB7IGRpc3BsYXk6IGxvZ2luVmlzaWJsZSA/ICdub25lJyA6ICcnIH1cbiAgICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IGxvZ2luVmlzaWJsZSA/ICcnIDogJ25vbmUnIH1cblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TG9naW5WaXNpYmxlKHRydWUpfT5sb2cgaW48L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG4gICAgICAgICAgPExvZ2luRm9ybVxuICAgICAgICAgICAgdXNlcm5hbWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgcGFzc3dvcmQ9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgaGFuZGxlVXNlcm5hbWVDaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgaGFuZGxlUGFzc3dvcmRDaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgaGFuZGxlU3VibWl0PXtoYW5kbGVMb2dpbn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TG9naW5WaXNpYmxlKGZhbHNlKX0+Y2FuY2VsPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgxPk5vdGVzPC9oMT5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfSAvPlxuXG4gICAgICB7IXVzZXIgJiYgbG9naW5Gb3JtKCl9XG4gICAgICB7dXNlciAmJiA8ZGl2PlxuICAgICAgICA8cD57dXNlci5uYW1lfSBsb2dnZWQgaW48L3A+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cbiAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD0nbmV3IG5vdGUnIHJlZj17bm90ZUZvcm1SZWZ9PlxuICAgICAgICAgIDxOb3RlRm9ybVxuICAgICAgICAgICAgY3JlYXRlTm90ZT17YWRkTm90ZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgIDwvZGl2Pn1cblxuICAgICAgPGRpdj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWxsKCFzaG93QWxsKX0+XG4gICAgICAgICAgc2hvdyB7c2hvd0FsbCA/ICdpbXBvcnRhbnQnIDogJ2FsbCcgfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPHVsPlxuICAgICAgICB7bm90ZXNUb1Nob3cubWFwKG5vdGUgPT5cbiAgICAgICAgICA8Tm90ZVxuICAgICAgICAgICAga2V5PXtub3RlLmlkfVxuICAgICAgICAgICAgbm90ZT17bm90ZX1cbiAgICAgICAgICAgIHRvZ2dsZUltcG9ydGFuY2U9eygpID0+IHRvZ2dsZUltcG9ydGFuY2VPZihub3RlLmlkKX1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgPC91bD5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9hZG1pbi9NaW5pIFByb2plY3RzL3BhcnQyLW5vdGVzLWZlLWRlYnVnL3NyYy9BcHAuanN4In0=