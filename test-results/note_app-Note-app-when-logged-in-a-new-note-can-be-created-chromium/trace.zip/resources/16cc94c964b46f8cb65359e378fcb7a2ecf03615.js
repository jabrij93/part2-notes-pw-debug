import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Note.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f925d25"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Note.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Note = ({ note, toggleImportance }) => {
  const label = note.important ? "make not important" : "make important";
  return /* @__PURE__ */ jsxDEV("li", { className: "note", children: [
    /* @__PURE__ */ jsxDEV("span", { children: [
      note.content,
      ", ",
      note.date ? note.date.split("T")[0].split("-").reverse().join("-") : "No date available",
      " "
    ] }, void 0, true, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Note.jsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: toggleImportance, children: label }, void 0, false, {
      fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Note.jsx",
      lineNumber: 8,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Note.jsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = Note;
export default Note;
var _c;
$RefreshReg$(_c, "Note");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/admin/Mini Projects/part2-notes-fe-debug/src/components/Note.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07QUFOTixPQUFNQSxvQkFBZ0JDO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxRQUFNQyxRQUFRQyxLQUFLQyxZQUNmLHVCQUF1QjtBQUUzQixTQUNFLHVCQUFDLFFBQUcsV0FBVSxRQUNaO0FBQUEsMkJBQUMsVUFBTUQ7QUFBQUEsV0FBS0U7QUFBQUEsTUFBUTtBQUFBLE1BQUdGLEtBQUtHLE9BQU9ILEtBQUtHLEtBQUtDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRUEsTUFBTSxHQUFHLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxHQUFHLElBQUk7QUFBQSxNQUFvQjtBQUFBLFNBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUg7QUFBQSxJQUNqSCx1QkFBQyxZQUFPLFNBQVNSLGtCQUFtQkMsbUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxPQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDUSxLQVZLVjtBQVlOLGVBQWVBO0FBQUksSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5vdGUiLCJ0b2dnbGVJbXBvcnRhbmNlIiwibGFiZWwiLCJub3RlIiwiaW1wb3J0YW50IiwiY29udGVudCIsImRhdGUiLCJzcGxpdCIsInJldmVyc2UiLCJqb2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBOb3RlID0gKHsgbm90ZSwgdG9nZ2xlSW1wb3J0YW5jZSB9KSA9PiB7XG4gIGNvbnN0IGxhYmVsID0gbm90ZS5pbXBvcnRhbnRcbiAgICA/ICdtYWtlIG5vdCBpbXBvcnRhbnQnIDogJ21ha2UgaW1wb3J0YW50J1xuXG4gIHJldHVybiAoXG4gICAgPGxpIGNsYXNzTmFtZT0nbm90ZSc+XG4gICAgICA8c3Bhbj57bm90ZS5jb250ZW50fSwge25vdGUuZGF0ZSA/IG5vdGUuZGF0ZS5zcGxpdCgnVCcpWzBdLnNwbGl0KCctJykucmV2ZXJzZSgpLmpvaW4oJy0nKSA6ICdObyBkYXRlIGF2YWlsYWJsZSd9IDwvc3Bhbj4gXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZUltcG9ydGFuY2V9PntsYWJlbH08L2J1dHRvbj5cbiAgICA8L2xpPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGUiXSwiZmlsZSI6Ii9Vc2Vycy9hZG1pbi9NaW5pIFByb2plY3RzL3BhcnQyLW5vdGVzLWZlLWRlYnVnL3NyYy9jb21wb25lbnRzL05vdGUuanN4In0=